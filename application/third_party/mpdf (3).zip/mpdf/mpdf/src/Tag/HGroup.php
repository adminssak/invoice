<?php

namespace Mpdf\Tag;

class HGroup extends BlockTag
{


}
