<?php

namespace Mpdf\Tag;

class Aside extends BlockTag
{


}
